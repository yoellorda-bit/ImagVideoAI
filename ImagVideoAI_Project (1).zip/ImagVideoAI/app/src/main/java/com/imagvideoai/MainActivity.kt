package com.imagvideoai

import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40,60,40,40) }
        val title = TextView(this).apply { text = "ImagVideo AI"; textSize = 30f; setPadding(0,0,0,40) }
        fun button(text: String, message: String) = Button(this).apply { this.text = text; setOnClickListener { Toast.makeText(context,message,Toast.LENGTH_SHORT).show() } }
        layout.addView(title)
        layout.addView(button("🖼️ Crear imagen", "Módulo de imágenes listo para conectar."))
        layout.addView(button("🎬 Crear video", "Módulo de video listo para conectar."))
        layout.addView(button("🎨 Cambiar apariencia", "Sistema de temas preparado."))
        setContentView(layout)
    }
}
